from enum import Enum

class PoolType(Enum):
    VOLATILE = 0
    STABLE = 1