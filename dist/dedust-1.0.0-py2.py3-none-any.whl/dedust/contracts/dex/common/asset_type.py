from enum import Enum

class AssetType(Enum):
    NATIVE = 0
    JETTON = 1